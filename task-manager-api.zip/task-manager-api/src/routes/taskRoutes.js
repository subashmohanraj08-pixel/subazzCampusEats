const express = require('express');
const {
  createTask,
  getTasks,
  getTaskById,
  updateTask,
  deleteTask,
} = require('../controllers/taskController');
const { protect } = require('../middleware/auth');
const validate = require('../middleware/validate');
const {
  createTaskValidation,
  updateTaskValidation,
  idParamValidation,
  listTasksValidation,
} = require('../utils/validators');

const router = express.Router();

// All task routes require authentication
router.use(protect);

router
  .route('/')
  .post(createTaskValidation, validate, createTask)
  .get(listTasksValidation, validate, getTasks);

router
  .route('/:id')
  .get(idParamValidation, validate, getTaskById)
  .put(updateTaskValidation, validate, updateTask)
  .delete(idParamValidation, validate, deleteTask);

module.exports = router;
