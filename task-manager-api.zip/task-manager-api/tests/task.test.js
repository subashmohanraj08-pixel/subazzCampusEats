const request = require('supertest');
const app = require('../src/app');

const userA = { name: 'User A', email: 'usera@example.com', password: 'password123' };
const userB = { name: 'User B', email: 'userb@example.com', password: 'password123' };

const getToken = async (user) => {
  const res = await request(app).post('/api/auth/register').send(user);
  return res.body.data.token;
};

describe('Task API', () => {
  let tokenA;
  let tokenB;

  beforeEach(async () => {
    tokenA = await getToken(userA);
    tokenB = await getToken(userB);
  });

  describe('POST /api/tasks', () => {
    it('should reject unauthenticated requests', async () => {
      const res = await request(app).post('/api/tasks').send({ title: 'No auth task' });
      expect(res.statusCode).toBe(401);
    });

    it('should create a task for the logged-in user', async () => {
      const res = await request(app)
        .post('/api/tasks')
        .set('Authorization', `Bearer ${tokenA}`)
        .send({ title: 'Buy groceries', priority: 'high' });

      expect(res.statusCode).toBe(201);
      expect(res.body.data.task.title).toBe('Buy groceries');
      expect(res.body.data.task.status).toBe('pending'); // default
    });

    it('should reject a task with no title', async () => {
      const res = await request(app)
        .post('/api/tasks')
        .set('Authorization', `Bearer ${tokenA}`)
        .send({ description: 'missing title' });

      expect(res.statusCode).toBe(400);
    });

    it('should reject an invalid status value', async () => {
      const res = await request(app)
        .post('/api/tasks')
        .set('Authorization', `Bearer ${tokenA}`)
        .send({ title: 'Bad status', status: 'not-a-real-status' });

      expect(res.statusCode).toBe(400);
    });
  });

  describe('GET /api/tasks', () => {
    it('should only return tasks owned by the requesting user', async () => {
      await request(app).post('/api/tasks').set('Authorization', `Bearer ${tokenA}`).send({ title: 'A1' });
      await request(app).post('/api/tasks').set('Authorization', `Bearer ${tokenB}`).send({ title: 'B1' });

      const res = await request(app).get('/api/tasks').set('Authorization', `Bearer ${tokenA}`);

      expect(res.statusCode).toBe(200);
      expect(res.body.data.tasks).toHaveLength(1);
      expect(res.body.data.tasks[0].title).toBe('A1');
    });

    it('should filter tasks by status', async () => {
      await request(app).post('/api/tasks').set('Authorization', `Bearer ${tokenA}`).send({ title: 'Pending task' });
      const created = await request(app)
        .post('/api/tasks')
        .set('Authorization', `Bearer ${tokenA}`)
        .send({ title: 'Done task', status: 'completed' });

      const res = await request(app)
        .get('/api/tasks?status=completed')
        .set('Authorization', `Bearer ${tokenA}`);

      expect(res.statusCode).toBe(200);
      expect(res.body.data.tasks).toHaveLength(1);
      expect(res.body.data.tasks[0]._id).toBe(created.body.data.task._id);
    });

    it('should paginate results', async () => {
      for (let i = 0; i < 15; i++) {
        await request(app).post('/api/tasks').set('Authorization', `Bearer ${tokenA}`).send({ title: `Task ${i}` });
      }

      const res = await request(app)
        .get('/api/tasks?page=2&limit=10')
        .set('Authorization', `Bearer ${tokenA}`);

      expect(res.statusCode).toBe(200);
      expect(res.body.data.tasks).toHaveLength(5);
      expect(res.body.pagination.total).toBe(15);
      expect(res.body.pagination.page).toBe(2);
    });
  });

  describe('GET /api/tasks/:id', () => {
    it('should return a single task by id', async () => {
      const created = await request(app)
        .post('/api/tasks')
        .set('Authorization', `Bearer ${tokenA}`)
        .send({ title: 'Findable task' });

      const res = await request(app)
        .get(`/api/tasks/${created.body.data.task._id}`)
        .set('Authorization', `Bearer ${tokenA}`);

      expect(res.statusCode).toBe(200);
      expect(res.body.data.task.title).toBe('Findable task');
    });

    it('should not allow a user to access another user\'s task', async () => {
      const created = await request(app)
        .post('/api/tasks')
        .set('Authorization', `Bearer ${tokenA}`)
        .send({ title: 'Private task' });

      const res = await request(app)
        .get(`/api/tasks/${created.body.data.task._id}`)
        .set('Authorization', `Bearer ${tokenB}`);

      expect(res.statusCode).toBe(404);
    });

    it('should return 400 for a malformed id', async () => {
      const res = await request(app).get('/api/tasks/not-a-valid-id').set('Authorization', `Bearer ${tokenA}`);
      expect(res.statusCode).toBe(400);
    });

    it('should return 404 for a well-formed but non-existent id', async () => {
      const res = await request(app)
        .get('/api/tasks/64f0c1a1e1b2c3d4e5f6a7b8')
        .set('Authorization', `Bearer ${tokenA}`);
      expect(res.statusCode).toBe(404);
    });
  });

  describe('PUT /api/tasks/:id', () => {
    it('should update an owned task', async () => {
      const created = await request(app)
        .post('/api/tasks')
        .set('Authorization', `Bearer ${tokenA}`)
        .send({ title: 'Old title' });

      const res = await request(app)
        .put(`/api/tasks/${created.body.data.task._id}`)
        .set('Authorization', `Bearer ${tokenA}`)
        .send({ title: 'New title', status: 'in-progress' });

      expect(res.statusCode).toBe(200);
      expect(res.body.data.task.title).toBe('New title');
      expect(res.body.data.task.status).toBe('in-progress');
    });

    it('should not allow updating another user\'s task', async () => {
      const created = await request(app)
        .post('/api/tasks')
        .set('Authorization', `Bearer ${tokenA}`)
        .send({ title: 'A task' });

      const res = await request(app)
        .put(`/api/tasks/${created.body.data.task._id}`)
        .set('Authorization', `Bearer ${tokenB}`)
        .send({ title: 'Hijacked' });

      expect(res.statusCode).toBe(404);
    });
  });

  describe('DELETE /api/tasks/:id', () => {
    it('should delete an owned task', async () => {
      const created = await request(app)
        .post('/api/tasks')
        .set('Authorization', `Bearer ${tokenA}`)
        .send({ title: 'To be deleted' });

      const res = await request(app)
        .delete(`/api/tasks/${created.body.data.task._id}`)
        .set('Authorization', `Bearer ${tokenA}`);

      expect(res.statusCode).toBe(200);

      const getRes = await request(app)
        .get(`/api/tasks/${created.body.data.task._id}`)
        .set('Authorization', `Bearer ${tokenA}`);
      expect(getRes.statusCode).toBe(404);
    });

    it('should not allow deleting another user\'s task', async () => {
      const created = await request(app)
        .post('/api/tasks')
        .set('Authorization', `Bearer ${tokenA}`)
        .send({ title: 'Protected task' });

      const res = await request(app)
        .delete(`/api/tasks/${created.body.data.task._id}`)
        .set('Authorization', `Bearer ${tokenB}`);

      expect(res.statusCode).toBe(404);
    });
  });
});
