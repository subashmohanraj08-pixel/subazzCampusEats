# Task Manager API

A RESTful API for managing personal tasks, built with **Node.js**, **Express**, and **MongoDB**. Supports user registration/login with **JWT authentication** and full **CRUD** operations on tasks, with each user only able to see and modify their own tasks.

This project was built for **Week 3 Task: Back-End API Development**.

---

## Features

- User registration & login with hashed passwords (bcrypt)
- JWT-based authentication for protected routes
- Full CRUD for tasks (Create, Read, Update, Delete)
- Task ownership — users can only access their own tasks
- Input validation on every endpoint (express-validator)
- Centralized error handling with consistent JSON responses
- Filtering (`status`, `priority`) and pagination on task listing
- Security middleware: `helmet`, `cors`, rate limiting
- Request logging (`morgan`)
- Automated tests with Jest + Supertest + an in-memory MongoDB instance

---

## Tech Stack

| Layer          | Technology                          |
|----------------|--------------------------------------|
| Runtime        | Node.js (v18+)                      |
| Framework      | Express.js                          |
| Database       | MongoDB (via Mongoose ODM)          |
| Auth           | JSON Web Tokens (JWT) + bcryptjs    |
| Validation     | express-validator                   |
| Testing        | Jest, Supertest, mongodb-memory-server |

---

## Project Structure

```
task-manager-api/
├── src/
│   ├── config/
│   │   └── db.js               # MongoDB connection
│   ├── controllers/
│   │   ├── authController.js   # register, login, getMe
│   │   └── taskController.js   # task CRUD logic
│   ├── middleware/
│   │   ├── auth.js             # JWT protect middleware
│   │   ├── errorHandler.js     # AppError class + central error handler
│   │   └── validate.js         # express-validator result handler
│   ├── models/
│   │   ├── User.js             # User schema (password hashing)
│   │   └── Task.js             # Task schema
│   ├── routes/
│   │   ├── authRoutes.js
│   │   └── taskRoutes.js
│   ├── utils/
│   │   ├── generateToken.js
│   │   └── validators.js       # express-validator rule sets
│   ├── app.js                  # Express app (middleware + routes)
│   └── server.js               # Entry point — connects DB & starts server
├── tests/
│   ├── setup.js                # Jest + in-memory MongoDB setup
│   ├── auth.test.js
│   └── task.test.js
├── .env.example
├── .gitignore
├── jest.config.js
├── package.json
├── README.md
└── API_DOCUMENTATION.md
```

---

## Prerequisites

- [Node.js](https://nodejs.org/) v18 or higher
- npm (comes with Node.js)
- A MongoDB instance — either:
  - [MongoDB Community Server](https://www.mongodb.com/try/download/community) running locally, **or**
  - A free [MongoDB Atlas](https://www.mongodb.com/cloud/atlas) cluster

---

## Setup & Installation

1. **Clone / extract the project**

   ```bash
   cd task-manager-api
   ```

2. **Install dependencies**

   ```bash
   npm install
   ```

3. **Configure environment variables**

   Copy the example file and fill in your own values:

   ```bash
   cp .env.example .env
   ```

   Edit `.env`:

   ```env
   PORT=5000
   NODE_ENV=development
   MONGO_URI=mongodb://127.0.0.1:27017/task_manager
   JWT_SECRET=replace_this_with_a_long_random_secret_string
   JWT_EXPIRES_IN=7d
   RATE_LIMIT_WINDOW_MS=900000
   RATE_LIMIT_MAX_REQUESTS=100
   ```

   > Generate a strong `JWT_SECRET` with: `node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"`

4. **Start MongoDB** (skip if using Atlas)

   ```bash
   mongod
   ```

5. **Run the server**

   ```bash
   # development (auto-restarts on file changes)
   npm run dev

   # production
   npm start
   ```

   The API will be available at `http://localhost:5000`.

6. **Verify it's running**

   ```bash
   curl http://localhost:5000/api/health
   ```

   Expected response:

   ```json
   { "success": true, "message": "API is healthy", "timestamp": "..." }
   ```

---

## Running Tests

Tests use an **in-memory MongoDB instance** (via `mongodb-memory-server`), so no real database connection or `.env` file is required to run them.

```bash
npm test
```

This runs the full suite covering:
- User registration (success, duplicate email, invalid email, weak password)
- Login (success, wrong password, non-existent user)
- Protected profile route
- Task creation, listing (with filters & pagination), retrieval, update, and deletion
- Cross-user access control (a user cannot read/update/delete another user's tasks)

---

## Quick Start Example (cURL)

```bash
# 1. Register
curl -X POST http://localhost:5000/api/auth/register \
  -H "Content-Type: application/json" \
  -d '{"name":"Jane Doe","email":"jane@example.com","password":"secret123"}'

# 2. Login (copy the "token" from the response)
curl -X POST http://localhost:5000/api/auth/login \
  -H "Content-Type: application/json" \
  -d '{"email":"jane@example.com","password":"secret123"}'

# 3. Create a task (replace <TOKEN>)
curl -X POST http://localhost:5000/api/tasks \
  -H "Content-Type: application/json" \
  -H "Authorization: Bearer <TOKEN>" \
  -d '{"title":"Finish assignment","priority":"high","status":"in-progress"}'

# 4. List your tasks
curl http://localhost:5000/api/tasks -H "Authorization: Bearer <TOKEN>"
```

Full endpoint reference: see [`API_DOCUMENTATION.md`](./API_DOCUMENTATION.md).

---

## Security & Best Practices Implemented

- Passwords hashed with bcrypt (never stored or returned in plain text)
- JWT authentication with configurable expiry
- Per-user data isolation (ownership checks on every task operation)
- Centralized, consistent error responses (no leaking stack traces in production)
- Input validation & sanitization on all write endpoints
- `helmet` for secure HTTP headers
- Rate limiting to mitigate brute-force/DoS attempts
- Environment-based configuration via `.env` (never committed — see `.gitignore`)

---

## License

ISC — free to use for educational purposes.
