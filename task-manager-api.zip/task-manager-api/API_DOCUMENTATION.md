# API Documentation — Task Manager API

**Base URL:** `http://localhost:5000/api`

## Conventions

- All request/response bodies are `application/json`.
- Protected routes require an `Authorization: Bearer <token>` header.
- All responses follow this envelope:

  ```json
  { "success": true, "message": "...", "data": { ... } }
  ```

  or, on error:

  ```json
  { "success": false, "message": "...", "errors": [ ... ] }
  ```

- Dates are ISO 8601 strings.

---

## Table of Contents

1. [Health Check](#health-check)
2. [Auth — Register](#1-register-a-user)
3. [Auth — Login](#2-login)
4. [Auth — Get Profile](#3-get-current-user-profile)
5. [Tasks — Create](#4-create-a-task)
6. [Tasks — List (filter + paginate)](#5-list-tasks)
7. [Tasks — Get One](#6-get-a-single-task)
8. [Tasks — Update](#7-update-a-task)
9. [Tasks — Delete](#8-delete-a-task)
10. [Error Response Reference](#error-response-reference)

---

## Health Check

### `GET /api/health`

Simple uptime check. No auth required.

**Response `200 OK`**
```json
{ "success": true, "message": "API is healthy", "timestamp": "2026-09-10T05:00:00.000Z" }
```

---

## 1. Register a user

### `POST /api/auth/register`

**Access:** Public

**Request Body**

| Field    | Type   | Required | Rules                              |
|----------|--------|----------|-------------------------------------|
| name     | string | Yes      | 2–50 characters                     |
| email    | string | Yes      | Valid email, must be unique         |
| password | string | Yes      | Minimum 6 characters                |

**Example Request**
```json
{
  "name": "Jane Doe",
  "email": "jane@example.com",
  "password": "secret123"
}
```

**Success Response `201 Created`**
```json
{
  "success": true,
  "message": "User registered successfully",
  "data": {
    "user": {
      "_id": "66f0c1a1e1b2c3d4e5f6a7b8",
      "name": "Jane Doe",
      "email": "jane@example.com",
      "createdAt": "2026-09-10T05:00:00.000Z",
      "updatedAt": "2026-09-10T05:00:00.000Z"
    },
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  }
}
```

**Error Responses**
| Status | Cause                                  |
|--------|------------------------------------------|
| 400    | Validation failed (bad email, short password, missing name) |
| 409    | Email already registered                |

---

## 2. Login

### `POST /api/auth/login`

**Access:** Public

**Request Body**

| Field    | Type   | Required |
|----------|--------|----------|
| email    | string | Yes      |
| password | string | Yes      |

**Example Request**
```json
{ "email": "jane@example.com", "password": "secret123" }
```

**Success Response `200 OK`**
```json
{
  "success": true,
  "message": "Login successful",
  "data": {
    "user": { "_id": "66f0c1a1e1b2c3d4e5f6a7b8", "name": "Jane Doe", "email": "jane@example.com" },
    "token": "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9..."
  }
}
```

**Error Responses**
| Status | Cause                          |
|--------|----------------------------------|
| 400    | Missing/invalid email or password format |
| 401    | Incorrect email or password      |

---

## 3. Get current user profile

### `GET /api/auth/me`

**Access:** Private (requires token)

**Headers**
```
Authorization: Bearer <token>
```

**Success Response `200 OK`**
```json
{
  "success": true,
  "data": {
    "user": { "_id": "66f0c1a1e1b2c3d4e5f6a7b8", "name": "Jane Doe", "email": "jane@example.com" }
  }
}
```

**Error Responses**
| Status | Cause                        |
|--------|--------------------------------|
| 401    | Missing, invalid, or expired token |

---

## 4. Create a task

### `POST /api/tasks`

**Access:** Private

**Headers**
```
Authorization: Bearer <token>
```

**Request Body**

| Field       | Type   | Required | Rules                                              |
|-------------|--------|----------|------------------------------------------------------|
| title       | string | Yes      | 1–100 characters                                     |
| description | string | No       | Up to 1000 characters                                |
| status      | string | No       | One of: `pending`, `in-progress`, `completed` (default `pending`) |
| priority    | string | No       | One of: `low`, `medium`, `high` (default `medium`)   |
| dueDate     | string | No       | ISO 8601 date                                        |

**Example Request**
```json
{
  "title": "Finish assignment",
  "description": "Complete the back-end API task",
  "priority": "high",
  "status": "in-progress",
  "dueDate": "2026-09-15T00:00:00.000Z"
}
```

**Success Response `201 Created`**
```json
{
  "success": true,
  "message": "Task created",
  "data": {
    "task": {
      "_id": "66f0c2b2e1b2c3d4e5f6a7c9",
      "title": "Finish assignment",
      "description": "Complete the back-end API task",
      "status": "in-progress",
      "priority": "high",
      "dueDate": "2026-09-15T00:00:00.000Z",
      "owner": "66f0c1a1e1b2c3d4e5f6a7b8",
      "createdAt": "2026-09-10T05:05:00.000Z",
      "updatedAt": "2026-09-10T05:05:00.000Z"
    }
  }
}
```

**Error Responses**
| Status | Cause                              |
|--------|--------------------------------------|
| 400    | Validation failed (missing title, invalid status/priority/date) |
| 401    | Missing or invalid token             |

---

## 5. List tasks

### `GET /api/tasks`

**Access:** Private — returns only tasks owned by the authenticated user.

**Headers**
```
Authorization: Bearer <token>
```

**Query Parameters** (all optional)

| Param    | Type    | Description                          |
|----------|---------|----------------------------------------|
| status   | string  | Filter by `pending` \| `in-progress` \| `completed` |
| priority | string  | Filter by `low` \| `medium` \| `high` |
| page     | integer | Page number (default `1`)             |
| limit    | integer | Items per page, 1–100 (default `10`)  |

**Example Request**
```
GET /api/tasks?status=pending&priority=high&page=1&limit=10
```

**Success Response `200 OK`**
```json
{
  "success": true,
  "data": {
    "tasks": [
      { "_id": "66f0c2b2e1b2c3d4e5f6a7c9", "title": "Finish assignment", "status": "pending", "priority": "high", "owner": "66f0c1a1e1b2c3d4e5f6a7b8" }
    ]
  },
  "pagination": { "total": 1, "page": 1, "limit": 10, "totalPages": 1 }
}
```

**Error Responses**
| Status | Cause                          |
|--------|----------------------------------|
| 400    | Invalid query parameter value    |
| 401    | Missing or invalid token         |

---

## 6. Get a single task

### `GET /api/tasks/:id`

**Access:** Private — 404 returned if the task doesn't exist **or** belongs to another user (prevents leaking existence of other users' data).

**Headers**
```
Authorization: Bearer <token>
```

**URL Parameters**

| Param | Type   | Description        |
|-------|--------|---------------------|
| id    | string | MongoDB ObjectId of the task |

**Success Response `200 OK`**
```json
{
  "success": true,
  "data": { "task": { "_id": "66f0c2b2e1b2c3d4e5f6a7c9", "title": "Finish assignment", "status": "pending" } }
}
```

**Error Responses**
| Status | Cause                            |
|--------|-------------------------------------|
| 400    | `id` is not a valid ObjectId         |
| 401    | Missing or invalid token             |
| 404    | Task not found / not owned by user   |

---

## 7. Update a task

### `PUT /api/tasks/:id`

**Access:** Private (owner only)

**Headers**
```
Authorization: Bearer <token>
```

**URL Parameters**

| Param | Type   | Description                  |
|-------|--------|-------------------------------|
| id    | string | MongoDB ObjectId of the task  |

**Request Body** (all fields optional — only send what you want to change)

| Field       | Type   | Rules                                                |
|-------------|--------|--------------------------------------------------------|
| title       | string | 1–100 characters if provided                           |
| description | string | Up to 1000 characters                                   |
| status      | string | One of: `pending`, `in-progress`, `completed`           |
| priority    | string | One of: `low`, `medium`, `high`                         |
| dueDate     | string | ISO 8601 date                                            |

**Example Request**
```json
{ "status": "completed" }
```

**Success Response `200 OK`**
```json
{
  "success": true,
  "message": "Task updated",
  "data": { "task": { "_id": "66f0c2b2e1b2c3d4e5f6a7c9", "title": "Finish assignment", "status": "completed" } }
}
```

**Error Responses**
| Status | Cause                            |
|--------|-------------------------------------|
| 400    | Validation failed / invalid id       |
| 401    | Missing or invalid token             |
| 404    | Task not found / not owned by user   |

---

## 8. Delete a task

### `DELETE /api/tasks/:id`

**Access:** Private (owner only)

**Headers**
```
Authorization: Bearer <token>
```

**URL Parameters**

| Param | Type   | Description                  |
|-------|--------|-------------------------------|
| id    | string | MongoDB ObjectId of the task  |

**Success Response `200 OK`**
```json
{ "success": true, "message": "Task deleted", "data": { "id": "66f0c2b2e1b2c3d4e5f6a7c9" } }
```

**Error Responses**
| Status | Cause                            |
|--------|-------------------------------------|
| 400    | `id` is not a valid ObjectId         |
| 401    | Missing or invalid token             |
| 404    | Task not found / not owned by user   |

---

## Error Response Reference

| Status Code | Meaning                | Typical Cause                                      |
|-------------|-------------------------|------------------------------------------------------|
| 400         | Bad Request              | Validation failure, malformed ObjectId               |
| 401         | Unauthorized             | Missing/invalid/expired JWT, wrong login credentials  |
| 404         | Not Found                | Resource doesn't exist, unmatched route, or not owned by requester |
| 409         | Conflict                 | Duplicate email on registration                       |
| 429         | Too Many Requests        | Rate limit exceeded                                    |
| 500         | Internal Server Error    | Unexpected server-side failure                         |

**Validation error example (`400`)**
```json
{
  "success": false,
  "message": "Validation failed",
  "errors": [
    { "field": "email", "message": "Must be a valid email" },
    { "field": "password", "message": "Password must be at least 6 characters" }
  ]
}
```
