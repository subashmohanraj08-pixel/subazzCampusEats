# Greenhouse

A front-end web app for tracking houseplant watering schedules and care history. Built as a front-end development
exercise: a responsive, accessible, componentized React app with three interconnected views and a mock service
layer standing in for a back end.

**Live views:** Landing page → Dashboard (plant collection) → Plant detail page.

---

## 1. What it does

Greenhouse lets a hobbyist gardener:

- See every plant they own grouped by room, with a live status (overdue / due soon / on schedule) computed from
  each plant's watering interval.
- Mark a plant watered in one click, from either the dashboard or its detail page.
- Add a new plant through a form (name, species, room, light, watering interval, notes).
- Open a plant's detail page to see its care history (waterings, feedings, repottings) as a timeline, read notes,
  and remove it from the collection.
- Search and sort the collection, and see summary stats (total plants, overdue, due soon, on schedule).

Sample data (6 plants across 3 rooms) is seeded automatically on first load so the app is usable immediately with
no setup.

---

## 2. Development process

1. **Defined the subject and audience** — a hobbyist with several houseplants, not a nursery-management tool. That
   scope shaped the data model (a handful of plants, simple room grouping) and the tone of the copy.
2. **Sketched the three required views as wireframes** (see `docs/wireframes.txt` for the ASCII layout sketches
   used to plan the hero, the shelf-grouped dashboard, and the detail page before any code was written).
3. **Designed a small token system** before touching CSS: a botanical palette (moss green, terracotta clay, amber),
   a serif display face (Fraunces) paired with a sans body face (Public Sans), and a shelf/room metaphor for the
   dashboard layout instead of a generic card grid.
4. **Built a service layer first** (`src/services/plantService.js`), independent of any UI, so every screen would
   consume the same async, Promise-based API a real back end would expose.
5. **Built outward from data to components to pages** — context → shared components (card, shelf, modal, timeline,
   stat bar) → the three pages → routing and navigation.
6. **Tested interactions by hand**: adding a plant with a blank name (validation), watering a plant and watching
   its status recompute, deleting a plant, searching with no results, loading a detail page directly by URL
   (deep link), and resizing down to a 360px viewport.

---

## 3. Architecture and patterns

```
src/
├── main.jsx                  # App entry: router + global state provider
├── App.jsx                   # Route table + persistent nav/footer
├── index.css                 # Design tokens (CSS custom properties) + resets
├── services/
│   └── plantService.js       # Mock back end: Promise-based CRUD + status calc
├── context/
│   └── PlantsContext.jsx     # App-wide plant state (React Context + hooks)
├── data/
│   └── seedPlants.js         # Seed records for the mock back end
├── pages/                    # One file per route (the 3 required views + 404)
│   ├── Landing.jsx
│   ├── Dashboard.jsx
│   └── PlantDetail.jsx
└── components/                # Reusable, presentational-first building blocks
    ├── Navbar.jsx / Footer.jsx
    ├── StatBar.jsx
    ├── PlantShelf.jsx / PlantCard.jsx
    ├── AddPlantModal.jsx
    ├── CareTimeline.jsx
    └── WaterButton.jsx
```

**Patterns used:**

- **Service layer / repository pattern** — `plantService.js` is the *only* module that touches storage. It returns
  Promises and simulates network latency (~300ms), so the rest of the app already handles loading and error states
  the way it would against a real REST API. Swapping localStorage for `fetch('/api/plants')` calls later would not
  require changing any component.
- **Container/presentational split** — `PlantsContext` and the page components own data-fetching and state;
  components like `PlantCard`, `StatBar`, and `CareTimeline` are given data as props and render it, making them
  reusable and easy to test in isolation.
- **Context + hooks for shared state** — `usePlants()` exposes `plants`, `status`, `addPlant`, `water`, and
  `remove` to any component, avoiding prop-drilling between the dashboard and detail views while still keeping a
  single source of truth.
- **Optimistic-friendly async UI** — `WaterButton` manages its own pending/confirmed state locally so it can be
  reused on both the dashboard card and the detail page without threading extra state through props.
- **Componentized, colocated styles** — each component/page has a matching `.css` file rather than one global
  stylesheet, so styles are easy to trace and don't leak across features.

---

## 4. Tech stack

| Tool | Why |
|---|---|
| **React 18** | Component model, hooks for state/effects. |
| **React Router 6** | Client-side routing between the three views (`/`, `/dashboard`, `/plants/:id`). |
| **Vite** | Fast dev server and build, minimal config. |
| **Plain CSS + custom properties** | No framework lock-in for this scope; keeps the design tokens explicit and easy to grade/inspect. |
| **Web localStorage** (via the service layer) | Stands in for a persistent back end without requiring a server for this exercise. |

No UI kit (e.g., Bootstrap/MUI) was used intentionally, so that layout, spacing, and accessibility choices in this
submission are all hand-built and inspectable.

---

## 5. Accessibility & responsiveness notes

- Semantic landmarks (`header`, `nav`, `main`, `footer`) and a "Skip to main content" link.
- All interactive controls are real `button`/`a`/`input` elements; nothing is a `div` with a click handler.
- Visible focus rings are preserved everywhere (`:focus-visible`), never suppressed.
- Form fields in the "Add a plant" modal all have associated `<label>`s; the modal traps focus on open, closes on
  `Escape`, and restores context via `aria-modal`.
- Status changes (watering a plant, loading states) use `aria-live`/`role="status"`/`role="alert"` so they're
  announced to screen readers.
- `prefers-reduced-motion` is respected globally.
- Layout is fluid from ~360px mobile width up through desktop: the hero, stat bar, and shelf grid all reflow via
  CSS Grid/Flexbox rather than fixed breakpoints alone.

---

## 6. Running it locally

**Requirements:** Node.js 18+ and npm.

```bash
# 1. Unzip and enter the project
cd greenhouse

# 2. Install dependencies
npm install

# 3. Start the dev server
npm run dev
```

Then open the URL Vite prints (defaults to `http://localhost:5173`) — it should also open automatically.

Other scripts:

```bash
npm run build     # Production build to /dist
npm run preview   # Serve the production build locally
npm run lint       # Run ESLint over src/
```

No environment variables, API keys, or external services are required — sample data is generated on first run and
persisted to the browser's localStorage from then on. To reset to the seed data, clear localStorage for the site
(DevTools → Application → Local Storage → remove the `greenhouse.plants.v1` key) and reload.

---

## 7. Known limitations / next steps

- Data is per-browser (localStorage), not shared across devices — swapping `plantService.js` for real HTTP calls
  is the natural next step and was designed for from the start.
- No automated test suite is included; interactions were verified manually (see §2). Adding React Testing Library
  coverage for `plantService` and the Dashboard/Detail flows would be the next investment.
- No image upload for plants — out of scope for this exercise but a natural feature to add.
