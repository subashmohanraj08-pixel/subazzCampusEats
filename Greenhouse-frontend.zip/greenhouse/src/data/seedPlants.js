// Seed records for the mock back end. In a production app this would live
// in a real database; here it stands in for one so the service layer has
// something realistic to serve on first load.

export const seedPlants = [
  {
    id: 'p1',
    name: 'Marlowe',
    species: 'Monstera deliciosa',
    room: 'Living room',
    light: 'Bright, indirect',
    waterEveryDays: 7,
    lastWatered: daysAgo(6),
    acquired: '2023-04-12',
    notes:
      'Getting a new fenestrated leaf every few weeks. Keep out of direct afternoon sun — the last one scorched.',
    history: [
      { date: daysAgo(6), action: 'Watered', detail: '600ml, soil was bone dry' },
      { date: daysAgo(13), action: 'Watered', detail: '500ml' },
      { date: daysAgo(20), action: 'Fed', detail: 'Half-strength liquid feed' },
      { date: daysAgo(20), action: 'Watered', detail: '500ml' },
    ],
  },
  {
    id: 'p2',
    name: 'Fitz',
    species: 'Ficus lyrata',
    room: 'Living room',
    light: 'Bright, indirect',
    waterEveryDays: 10,
    lastWatered: daysAgo(2),
    acquired: '2022-11-02',
    notes: 'Drama queen. Drops a leaf if you so much as look at it wrong. Rotate weekly for even growth.',
    history: [
      { date: daysAgo(2), action: 'Watered', detail: '700ml' },
      { date: daysAgo(12), action: 'Watered', detail: '700ml' },
      { date: daysAgo(22), action: 'Repotted', detail: 'Moved to a 12in terracotta pot' },
    ],
  },
  {
    id: 'p3',
    name: 'Basil Fawlty',
    species: 'Ocimum basilicum',
    room: 'Kitchen',
    light: 'Full sun',
    waterEveryDays: 3,
    lastWatered: daysAgo(4),
    acquired: '2024-05-30',
    notes: 'Pinch flower buds as soon as they appear or the leaves turn bitter.',
    history: [
      { date: daysAgo(4), action: 'Watered', detail: '150ml' },
      { date: daysAgo(7), action: 'Watered', detail: '150ml' },
      { date: daysAgo(9), action: 'Pruned', detail: 'Pinched two flower spikes' },
    ],
  },
  {
    id: 'p4',
    name: 'Sting', // a jade plant, thick-skinned
    species: 'Crassula ovata',
    room: 'Kitchen',
    light: 'Full sun',
    waterEveryDays: 18,
    lastWatered: daysAgo(9),
    acquired: '2021-08-19',
    notes: 'Oldest plant in the house. Basically indestructible — resist the urge to water more.',
    history: [
      { date: daysAgo(9), action: 'Watered', detail: '100ml, let it dry fully first' },
      { date: daysAgo(28), action: 'Watered', detail: '100ml' },
    ],
  },
  {
    id: 'p5',
    name: 'Wednesday',
    species: 'Zamioculcas zamiifolia',
    room: 'Office',
    light: 'Low light',
    waterEveryDays: 21,
    lastWatered: daysAgo(20),
    acquired: '2023-01-08',
    notes: 'Thrives on neglect. Perfect for the corner with no window.',
    history: [
      { date: daysAgo(20), action: 'Watered', detail: '150ml' },
      { date: daysAgo(41), action: 'Watered', detail: '150ml' },
      { date: daysAgo(41), action: 'Dusted leaves', detail: 'Wiped down with a damp cloth' },
    ],
  },
  {
    id: 'p6',
    name: 'Pothos Vader',
    species: 'Epipremnum aureum',
    room: 'Office',
    light: 'Low to medium',
    waterEveryDays: 9,
    lastWatered: daysAgo(11),
    acquired: '2022-03-15',
    notes: 'Vines are getting long — needs a trellis or a trim, whichever happens first.',
    history: [
      { date: daysAgo(11), action: 'Watered', detail: '300ml' },
      { date: daysAgo(20), action: 'Watered', detail: '300ml' },
      { date: daysAgo(30), action: 'Propagated', detail: 'Took 3 cuttings for a friend' },
    ],
  },
];

function daysAgo(n) {
  const d = new Date();
  d.setDate(d.getDate() - n);
  return d.toISOString().slice(0, 10);
}
