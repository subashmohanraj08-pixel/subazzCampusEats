// -----------------------------------------------------------------------
// plantService
//
// This module is the app's *only* point of contact with "the back end".
// Every read/write goes through here and returns a Promise, exactly like a
// real fetch() call would. Internally it persists to localStorage and adds
// artificial latency so the UI has to handle real loading/error states.
//
// Swapping this for a real API later means rewriting the bodies of these
// functions to call `fetch('/api/plants')` etc. — no component code
// should need to change, because the *shape* of what's returned stays
// the same. That boundary is the whole point of a service layer.
// -----------------------------------------------------------------------

import { seedPlants } from '../data/seedPlants.js';

const STORAGE_KEY = 'greenhouse.plants.v1';
const LATENCY_MS = 380;

function delay(ms = LATENCY_MS) {
  return new Promise((resolve) => setTimeout(resolve, ms));
}

function readStore() {
  const raw = window.localStorage.getItem(STORAGE_KEY);
  if (!raw) {
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(seedPlants));
    return structuredClone(seedPlants);
  }
  try {
    return JSON.parse(raw);
  } catch {
    // Corrupt local data — fall back to seed rather than crash the app.
    window.localStorage.setItem(STORAGE_KEY, JSON.stringify(seedPlants));
    return structuredClone(seedPlants);
  }
}

function writeStore(plants) {
  window.localStorage.setItem(STORAGE_KEY, JSON.stringify(plants));
}

function daysUntilNextWatering(plant) {
  const last = new Date(plant.lastWatered);
  const due = new Date(last);
  due.setDate(due.getDate() + plant.waterEveryDays);
  const today = new Date();
  const diffMs = due.setHours(0, 0, 0, 0) - today.setHours(0, 0, 0, 0);
  return Math.round(diffMs / 86400000);
}

function withStatus(plant) {
  const daysLeft = daysUntilNextWatering(plant);
  let status = 'healthy';
  if (daysLeft < 0) status = 'overdue';
  else if (daysLeft <= 1) status = 'due-soon';
  return { ...plant, daysLeft, status };
}

/** GET /plants */
export async function fetchPlants() {
  await delay();
  const plants = readStore();
  return plants.map(withStatus);
}

/** GET /plants/:id */
export async function fetchPlantById(id) {
  await delay();
  const plants = readStore();
  const plant = plants.find((p) => p.id === id);
  if (!plant) {
    const err = new Error(`No plant found with id "${id}"`);
    err.status = 404;
    throw err;
  }
  return withStatus(plant);
}

/** POST /plants */
export async function createPlant(input) {
  await delay();
  const plants = readStore();
  const newPlant = {
    id: `p${Date.now()}`,
    name: input.name.trim(),
    species: input.species.trim() || 'Unidentified',
    room: input.room.trim() || 'Unsorted',
    light: input.light || 'Bright, indirect',
    waterEveryDays: Number(input.waterEveryDays) || 7,
    lastWatered: new Date().toISOString().slice(0, 10),
    acquired: new Date().toISOString().slice(0, 10),
    notes: input.notes?.trim() || '',
    history: [{ date: new Date().toISOString().slice(0, 10), action: 'Added', detail: 'Joined the collection' }],
  };
  plants.unshift(newPlant);
  writeStore(plants);
  return withStatus(newPlant);
}

/** PATCH /plants/:id/water */
export async function waterPlant(id) {
  await delay(220);
  const plants = readStore();
  const idx = plants.findIndex((p) => p.id === id);
  if (idx === -1) {
    const err = new Error(`No plant found with id "${id}"`);
    err.status = 404;
    throw err;
  }
  const today = new Date().toISOString().slice(0, 10);
  plants[idx] = {
    ...plants[idx],
    lastWatered: today,
    history: [{ date: today, action: 'Watered', detail: 'Marked from the dashboard' }, ...plants[idx].history],
  };
  writeStore(plants);
  return withStatus(plants[idx]);
}

/** DELETE /plants/:id */
export async function removePlant(id) {
  await delay(220);
  const plants = readStore();
  const next = plants.filter((p) => p.id !== id);
  writeStore(next);
  return { id };
}

/** Utility export used by components that need the raw calculation. */
export { daysUntilNextWatering };
