import React from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import App from './App.jsx';
import { PlantsProvider } from './context/PlantsContext.jsx';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
      <PlantsProvider>
        <App />
      </PlantsProvider>
    </BrowserRouter>
  </React.StrictMode>
);
