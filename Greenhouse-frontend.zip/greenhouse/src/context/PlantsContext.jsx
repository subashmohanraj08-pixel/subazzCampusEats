import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import * as plantService from '../services/plantService.js';

const PlantsContext = createContext(null);

export function PlantsProvider({ children }) {
  const [plants, setPlants] = useState([]);
  const [status, setStatus] = useState('idle'); // idle | loading | ready | error
  const [error, setError] = useState(null);

  const load = useCallback(async () => {
    setStatus('loading');
    setError(null);
    try {
      const data = await plantService.fetchPlants();
      setPlants(data);
      setStatus('ready');
    } catch (err) {
      setError(err);
      setStatus('error');
    }
  }, []);

  useEffect(() => {
    load();
  }, [load]);

  const addPlant = useCallback(async (input) => {
    const created = await plantService.createPlant(input);
    setPlants((prev) => [created, ...prev]);
    return created;
  }, []);

  const water = useCallback(async (id) => {
    const updated = await plantService.waterPlant(id);
    setPlants((prev) => prev.map((p) => (p.id === id ? updated : p)));
    return updated;
  }, []);

  const remove = useCallback(async (id) => {
    await plantService.removePlant(id);
    setPlants((prev) => prev.filter((p) => p.id !== id));
  }, []);

  const value = useMemo(
    () => ({ plants, status, error, reload: load, addPlant, water, remove }),
    [plants, status, error, load, addPlant, water, remove]
  );

  return <PlantsContext.Provider value={value}>{children}</PlantsContext.Provider>;
}

export function usePlants() {
  const ctx = useContext(PlantsContext);
  if (!ctx) {
    throw new Error('usePlants must be used within a PlantsProvider');
  }
  return ctx;
}
