import { Link } from 'react-router-dom';
import './Landing.css';

const FEATURES = [
  {
    title: 'A watering schedule that adapts',
    body: "Every plant gets its own interval. Greenhouse tells you what's due today instead of making you guess from memory.",
  },
  {
    title: 'A history worth keeping',
    body: 'Feedings, repottings, and prunings are logged alongside waterings, so you can see how a plant has actually been cared for.',
  },
  {
    title: 'Organized the way your home is',
    body: 'Plants are grouped by room, not by an arbitrary list — the dashboard mirrors how you actually walk through the house.',
  },
];

export default function Landing() {
  return (
    <>
      <section className="hero">
        <div className="container hero__grid">
          <div className="hero__copy">
            <p className="hero__eyebrow">For people who own more than three houseplants</p>
            <h1 className="hero__headline">
              Know what needs
              <br />
              water before it wilts.
            </h1>
            <p className="hero__sub">
              Greenhouse keeps a watering interval, a care history, and a few honest notes for every plant you own — so
              "was it this week or last week?" stops being a question you ask.
            </p>
            <div className="hero__actions">
              <Link className="btn btn-primary" to="/dashboard">
                Open my dashboard
              </Link>
              <a className="btn btn-ghost" href="#how-it-works">
                See how it works
              </a>
            </div>
          </div>
          <div className="hero__art" aria-hidden="true">
            <svg viewBox="0 0 320 360" width="100%" height="100%">
              <ellipse cx="160" cy="330" rx="120" ry="14" fill="#1f2b20" opacity="0.06" />
              <path d="M120 340 L130 230 L190 230 L200 340 Z" fill="#a6543a" />
              <path d="M120 340 L130 230 L190 230 L200 340 Z" fill="url(#potShade)" opacity="0.5" />
              <rect x="112" y="215" width="96" height="20" rx="3" fill="#833f2a" />
              <path
                d="M160 230 C 120 210, 110 150, 140 110 C 150 95, 175 90, 180 105 C 200 95, 225 115, 210 140 C 235 145, 235 180, 205 190 C 215 210, 190 225, 170 210 C 172 220, 165 228, 160 230 Z"
                fill="#4a6741"
              />
              <path d="M160 230 C 150 190 148 150 165 110" stroke="#33482c" strokeWidth="3" fill="none" strokeLinecap="round" />
              <path d="M160 190 C 140 175 130 160 128 145" stroke="#33482c" strokeWidth="2.5" fill="none" strokeLinecap="round" />
              <path d="M168 170 C 188 158 198 145 202 130" stroke="#33482c" strokeWidth="2.5" fill="none" strokeLinecap="round" />
              <defs>
                <linearGradient id="potShade" x1="0" y1="0" x2="0" y2="1">
                  <stop offset="0" stopColor="#000000" stopOpacity="0" />
                  <stop offset="1" stopColor="#000000" stopOpacity="0.25" />
                </linearGradient>
              </defs>
            </svg>
          </div>
        </div>
      </section>

      <section className="container" id="how-it-works" style={{ padding: '4.5rem 1.5rem' }}>
        <h2 className="section-title">Three habits, one place</h2>
        <div className="features">
          {FEATURES.map((f) => (
            <article className="feature" key={f.title}>
              <h3>{f.title}</h3>
              <p>{f.body}</p>
            </article>
          ))}
        </div>
      </section>

      <section className="cta-band">
        <div className="container cta-band__inner">
          <div>
            <h2 style={{ color: 'white' }}>Six plants are already waiting on your dashboard.</h2>
            <p style={{ color: 'rgba(255,255,255,0.82)', marginBottom: 0 }}>
              Sample data is loaded automatically so you can try Greenhouse without setting anything up first.
            </p>
          </div>
          <Link className="btn btn-amber" to="/dashboard">
            Go to dashboard
          </Link>
        </div>
      </section>
    </>
  );
}
