import { Link } from 'react-router-dom';

export default function NotFound() {
  return (
    <div className="container" style={{ padding: '5rem 1.5rem', textAlign: 'center' }}>
      <h1 style={{ fontSize: '2.5rem', marginBottom: '0.75rem' }}>This bed's empty</h1>
      <p style={{ color: 'var(--color-ink-soft)', marginInline: 'auto' }}>
        There's nothing planted at this address. The page you're looking for doesn't exist.
      </p>
      <Link className="btn btn-primary" to="/" style={{ marginTop: '1.5rem' }}>
        Back to Greenhouse
      </Link>
    </div>
  );
}
