import { useMemo, useState } from 'react';
import { usePlants } from '../context/PlantsContext.jsx';
import StatBar from '../components/StatBar.jsx';
import PlantShelf from '../components/PlantShelf.jsx';
import AddPlantModal from '../components/AddPlantModal.jsx';
import './Dashboard.css';

const SORTS = {
  urgent: (a, b) => a.daysLeft - b.daysLeft,
  name: (a, b) => a.name.localeCompare(b.name),
  room: (a, b) => a.room.localeCompare(b.room),
};

export default function Dashboard() {
  const { plants, status, error, addPlant, water, reload } = usePlants();
  const [modalOpen, setModalOpen] = useState(false);
  const [sortBy, setSortBy] = useState('urgent');
  const [query, setQuery] = useState('');

  const filtered = useMemo(() => {
    const q = query.trim().toLowerCase();
    const list = q
      ? plants.filter((p) => p.name.toLowerCase().includes(q) || p.species.toLowerCase().includes(q) || p.room.toLowerCase().includes(q))
      : plants;
    return [...list].sort(SORTS[sortBy]);
  }, [plants, sortBy, query]);

  const shelves = useMemo(() => {
    const byRoom = new Map();
    for (const plant of filtered) {
      if (!byRoom.has(plant.room)) byRoom.set(plant.room, []);
      byRoom.get(plant.room).push(plant);
    }
    return Array.from(byRoom.entries());
  }, [filtered]);

  return (
    <div className="container dashboard">
      <div className="dashboard__head">
        <div>
          <h1>My plants</h1>
          <p className="dashboard__sub">Everything you're growing, sorted by what needs you most.</p>
        </div>
        <button type="button" className="btn btn-primary" onClick={() => setModalOpen(true)}>
          + Add a plant
        </button>
      </div>

      {status === 'loading' && (
        <p role="status" className="dashboard__state">
          Loading your collection…
        </p>
      )}

      {status === 'error' && (
        <div className="dashboard__state dashboard__state--error" role="alert">
          <p>Couldn't load your plants. {error?.message}</p>
          <button type="button" className="btn btn-ghost" onClick={reload}>
            Try again
          </button>
        </div>
      )}

      {status === 'ready' && (
        <>
          <StatBar plants={plants} />

          <div className="dashboard__controls">
            <div className="field" style={{ marginBottom: 0, flex: 1, maxWidth: '22rem' }}>
              <label htmlFor="search" className="visually-hidden">
                Search plants
              </label>
              <input
                id="search"
                type="search"
                placeholder="Search by name, species, or room…"
                value={query}
                onChange={(e) => setQuery(e.target.value)}
              />
            </div>
            <div className="dashboard__sort">
              <label htmlFor="sort">Sort by</label>
              <select id="sort" value={sortBy} onChange={(e) => setSortBy(e.target.value)}>
                <option value="urgent">Most urgent</option>
                <option value="name">Name</option>
                <option value="room">Room</option>
              </select>
            </div>
          </div>

          {shelves.length === 0 ? (
            <div className="dashboard__empty">
              <h2>Nothing matches "{query}"</h2>
              <p>Try a different search, or add a plant that doesn't exist yet.</p>
            </div>
          ) : (
            shelves.map(([room, roomPlants]) => (
              <PlantShelf key={room} room={room} plants={roomPlants} onWater={water} />
            ))
          )}
        </>
      )}

      <AddPlantModal open={modalOpen} onClose={() => setModalOpen(false)} onSubmit={addPlant} />
    </div>
  );
}
