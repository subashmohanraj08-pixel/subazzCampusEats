import { useEffect, useState } from 'react';
import { Link, useNavigate, useParams } from 'react-router-dom';
import { usePlants } from '../context/PlantsContext.jsx';
import * as plantService from '../services/plantService.js';
import WaterButton from '../components/WaterButton.jsx';
import CareTimeline from '../components/CareTimeline.jsx';
import './PlantDetail.css';

const STATUS_COPY = {
  overdue: (days) => `${Math.abs(days)} day${Math.abs(days) === 1 ? '' : 's'} overdue for water`,
  'due-soon': (days) => (days === 0 ? 'Due for water today' : 'Due for water tomorrow'),
  healthy: (days) => `On track — water again in ${days} days`,
};

export default function PlantDetail() {
  const { id } = useParams();
  const navigate = useNavigate();
  const { plants, water, remove } = usePlants();

  // Prefer the copy already in context (kept fresh by WaterButton actions);
  // fall back to a direct service call so a hard refresh / deep link works.
  const fromContext = plants.find((p) => p.id === id);
  const [plant, setPlant] = useState(fromContext ?? null);
  const [status, setStatus] = useState(fromContext ? 'ready' : 'loading');
  const [error, setError] = useState(null);
  const [deleting, setDeleting] = useState(false);

  useEffect(() => {
    if (fromContext) {
      setPlant(fromContext);
      setStatus('ready');
      return;
    }
    let cancelled = false;
    setStatus('loading');
    plantService
      .fetchPlantById(id)
      .then((data) => {
        if (!cancelled) {
          setPlant(data);
          setStatus('ready');
        }
      })
      .catch((err) => {
        if (!cancelled) {
          setError(err);
          setStatus('error');
        }
      });
    return () => {
      cancelled = true;
    };
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [id]);

  async function handleWater(plantId) {
    const updated = await water(plantId);
    setPlant(updated);
  }

  async function handleDelete() {
    if (!window.confirm(`Remove ${plant.name} from your collection? This can't be undone.`)) return;
    setDeleting(true);
    try {
      await remove(plant.id);
      navigate('/dashboard');
    } catch {
      setDeleting(false);
    }
  }

  if (status === 'loading') {
    return (
      <div className="container detail">
        <p role="status">Loading plant…</p>
      </div>
    );
  }

  if (status === 'error' || !plant) {
    return (
      <div className="container detail">
        <p role="alert">{error?.message || "We couldn't find that plant."}</p>
        <Link className="btn btn-ghost" to="/dashboard">
          Back to dashboard
        </Link>
      </div>
    );
  }

  return (
    <div className="container detail">
      <Link to="/dashboard" className="detail__back">
        ← Back to dashboard
      </Link>

      <div className="detail__head">
        <div>
          <p className="detail__room">{plant.room}</p>
          <h1>{plant.name}</h1>
          <p className="detail__species">{plant.species}</p>
        </div>
        <WaterButton plantId={plant.id} onWater={handleWater} variant="large" />
      </div>

      <p className={`detail__status is-${plant.status}`}>{STATUS_COPY[plant.status](plant.daysLeft)}</p>

      <dl className="detail__facts">
        <div>
          <dt>Light</dt>
          <dd>{plant.light}</dd>
        </div>
        <div>
          <dt>Watering interval</dt>
          <dd>Every {plant.waterEveryDays} days</dd>
        </div>
        <div>
          <dt>Last watered</dt>
          <dd>{new Date(plant.lastWatered).toLocaleDateString(undefined, { month: 'short', day: 'numeric' })}</dd>
        </div>
        <div>
          <dt>In the collection since</dt>
          <dd>{new Date(plant.acquired).toLocaleDateString(undefined, { month: 'short', year: 'numeric' })}</dd>
        </div>
      </dl>

      {plant.notes && (
        <section className="detail__notes">
          <h2>Notes</h2>
          <p>{plant.notes}</p>
        </section>
      )}

      <section className="detail__history">
        <h2>Care history</h2>
        <CareTimeline entries={plant.history} />
      </section>

      <button type="button" className="detail__delete" onClick={handleDelete} disabled={deleting}>
        {deleting ? 'Removing…' : 'Remove this plant'}
      </button>
    </div>
  );
}
