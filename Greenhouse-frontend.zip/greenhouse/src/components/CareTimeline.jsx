import './CareTimeline.css';

export default function CareTimeline({ entries }) {
  if (!entries?.length) {
    return <p className="timeline-empty">No care history logged yet.</p>;
  }

  return (
    <ol className="timeline">
      {entries.map((entry, i) => (
        <li className="timeline__item" key={`${entry.date}-${i}`}>
          <div className="timeline__marker" aria-hidden="true" />
          <div className="timeline__body">
            <div className="timeline__row">
              <span className="timeline__action">{entry.action}</span>
              <time className="timeline__date" dateTime={entry.date}>
                {formatDate(entry.date)}
              </time>
            </div>
            {entry.detail && <p className="timeline__detail">{entry.detail}</p>}
          </div>
        </li>
      ))}
    </ol>
  );
}

function formatDate(iso) {
  const d = new Date(iso);
  return d.toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' });
}
