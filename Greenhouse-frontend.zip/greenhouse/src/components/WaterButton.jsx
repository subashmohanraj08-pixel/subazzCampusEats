import { useState } from 'react';

/**
 * Marks a plant watered via the service layer (through context). Handles
 * its own pending/confirmed state so it works when reused on both the
 * dashboard cards and the detail page without prop-drilling extra state.
 */
export default function WaterButton({ plantId, onWater, variant = 'default' }) {
  const [pending, setPending] = useState(false);
  const [justWatered, setJustWatered] = useState(false);

  async function handleClick(e) {
    e.preventDefault();
    e.stopPropagation();
    if (pending) return;
    setPending(true);
    try {
      await onWater(plantId);
      setJustWatered(true);
      setTimeout(() => setJustWatered(false), 2200);
    } finally {
      setPending(false);
    }
  }

  return (
    <button
      type="button"
      className={variant === 'large' ? 'btn btn-amber' : 'btn btn-amber btn-sm'}
      onClick={handleClick}
      disabled={pending}
      aria-live="polite"
    >
      {pending ? 'Watering…' : justWatered ? 'Watered ✓' : 'Mark watered'}
    </button>
  );
}
