import './StatBar.css';

export default function StatBar({ plants }) {
  const total = plants.length;
  const overdue = plants.filter((p) => p.status === 'overdue').length;
  const dueSoon = plants.filter((p) => p.status === 'due-soon').length;
  const healthy = total - overdue - dueSoon;

  const stats = [
    { label: 'Plants in the collection', value: total },
    { label: 'Overdue for water', value: overdue, tone: 'danger' },
    { label: 'Due today or tomorrow', value: dueSoon, tone: 'amber' },
    { label: 'On schedule', value: healthy, tone: 'moss' },
  ];

  return (
    <dl className="statbar" aria-label="Watering summary">
      {stats.map((s) => (
        <div className="statbar__item" key={s.label}>
          <dt>{s.label}</dt>
          <dd className={s.tone ? `is-${s.tone}` : undefined}>{s.value}</dd>
        </div>
      ))}
    </dl>
  );
}
