import { useEffect, useRef, useState } from 'react';
import './AddPlantModal.css';

const LIGHT_OPTIONS = ['Full sun', 'Bright, indirect', 'Bright to medium', 'Low light'];

const EMPTY_FORM = {
  name: '',
  species: '',
  room: '',
  light: LIGHT_OPTIONS[1],
  waterEveryDays: 7,
  notes: '',
};

export default function AddPlantModal({ open, onClose, onSubmit }) {
  const [form, setForm] = useState(EMPTY_FORM);
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState(null);
  const dialogRef = useRef(null);
  const firstFieldRef = useRef(null);

  useEffect(() => {
    if (open) {
      setForm(EMPTY_FORM);
      setFormError(null);
      // Move focus into the dialog for keyboard/screen-reader users.
      setTimeout(() => firstFieldRef.current?.focus(), 0);
    }
  }, [open]);

  useEffect(() => {
    function handleKey(e) {
      if (e.key === 'Escape' && open) onClose();
    }
    document.addEventListener('keydown', handleKey);
    return () => document.removeEventListener('keydown', handleKey);
  }, [open, onClose]);

  if (!open) return null;

  function update(field, value) {
    setForm((prev) => ({ ...prev, [field]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    if (!form.name.trim()) {
      setFormError('Give the plant a name so you can find it again.');
      return;
    }
    setSubmitting(true);
    setFormError(null);
    try {
      await onSubmit(form);
      onClose();
    } catch (err) {
      setFormError(err.message || 'Something went wrong saving that plant.');
    } finally {
      setSubmitting(false);
    }
  }

  return (
    <div className="modal-backdrop" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div
        className="modal"
        role="dialog"
        aria-modal="true"
        aria-labelledby="add-plant-title"
        ref={dialogRef}
      >
        <div className="modal__head">
          <h2 id="add-plant-title">Add a plant</h2>
          <button type="button" className="modal__close" onClick={onClose} aria-label="Close dialog">
            ×
          </button>
        </div>

        <form onSubmit={handleSubmit} className="modal__form" noValidate>
          <div className="field">
            <label htmlFor="pf-name">Name</label>
            <input
              id="pf-name"
              ref={firstFieldRef}
              value={form.name}
              onChange={(e) => update('name', e.target.value)}
              placeholder="e.g. Gimli"
              required
            />
          </div>

          <div className="field-row">
            <div className="field">
              <label htmlFor="pf-species">Species</label>
              <input
                id="pf-species"
                value={form.species}
                onChange={(e) => update('species', e.target.value)}
                placeholder="e.g. Sansevieria trifasciata"
              />
            </div>
            <div className="field">
              <label htmlFor="pf-room">Room</label>
              <input
                id="pf-room"
                value={form.room}
                onChange={(e) => update('room', e.target.value)}
                placeholder="e.g. Bedroom"
              />
            </div>
          </div>

          <div className="field-row">
            <div className="field">
              <label htmlFor="pf-light">Light</label>
              <select id="pf-light" value={form.light} onChange={(e) => update('light', e.target.value)}>
                {LIGHT_OPTIONS.map((opt) => (
                  <option key={opt} value={opt}>
                    {opt}
                  </option>
                ))}
              </select>
            </div>
            <div className="field">
              <label htmlFor="pf-interval">Water every (days)</label>
              <input
                id="pf-interval"
                type="number"
                min="1"
                max="60"
                value={form.waterEveryDays}
                onChange={(e) => update('waterEveryDays', e.target.value)}
              />
            </div>
          </div>

          <div className="field">
            <label htmlFor="pf-notes">Notes</label>
            <textarea
              id="pf-notes"
              rows={3}
              value={form.notes}
              onChange={(e) => update('notes', e.target.value)}
              placeholder="Anything worth remembering — quirks, past problems, where you bought it."
            />
          </div>

          {formError && (
            <p role="alert" className="field-error">
              {formError}
            </p>
          )}

          <div className="modal__actions">
            <button type="button" className="btn btn-ghost" onClick={onClose}>
              Cancel
            </button>
            <button type="submit" className="btn btn-primary" disabled={submitting}>
              {submitting ? 'Adding…' : 'Add plant'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
