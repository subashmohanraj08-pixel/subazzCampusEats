import { Link } from 'react-router-dom';
import WaterButton from './WaterButton.jsx';
import './PlantCard.css';

const STATUS_COPY = {
  overdue: (days) => `${Math.abs(days)} day${Math.abs(days) === 1 ? '' : 's'} overdue`,
  'due-soon': (days) => (days === 0 ? 'Due today' : 'Due tomorrow'),
  healthy: (days) => `Water in ${days} days`,
};

export default function PlantCard({ plant, onWater }) {
  const copy = STATUS_COPY[plant.status](plant.daysLeft);

  return (
    <article className={`plant-card is-${plant.status}`}>
      <Link to={`/plants/${plant.id}`} className="plant-card__link">
        <div className="plant-card__top">
          <span className="plant-card__status-dot" aria-hidden="true" />
          <span className="plant-card__status-text">{copy}</span>
        </div>
        <h3 className="plant-card__name">{plant.name}</h3>
        <p className="plant-card__species">{plant.species}</p>
      </Link>
      <div className="plant-card__foot">
        <span className="plant-card__light">{plant.light}</span>
        <WaterButton plantId={plant.id} onWater={onWater} />
      </div>
    </article>
  );
}
