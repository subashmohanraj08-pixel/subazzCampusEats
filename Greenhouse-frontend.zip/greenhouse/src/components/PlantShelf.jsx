import PlantCard from './PlantCard.jsx';
import './PlantShelf.css';

export default function PlantShelf({ room, plants, onWater }) {
  return (
    <section className="shelf" aria-labelledby={`shelf-${room}`}>
      <h2 className="shelf__title" id={`shelf-${room}`}>
        {room}
        <span className="shelf__count">
          {plants.length} plant{plants.length === 1 ? '' : 's'}
        </span>
      </h2>
      <div className="shelf__rail" aria-hidden="true" />
      <div className="shelf__grid">
        {plants.map((plant) => (
          <PlantCard key={plant.id} plant={plant} onWater={onWater} />
        ))}
      </div>
    </section>
  );
}
