import { NavLink } from 'react-router-dom';
import './Navbar.css';

export default function Navbar() {
  return (
    <header className="nav">
      <div className="container nav__inner">
        <NavLink to="/" className="nav__brand" aria-label="Greenhouse home">
          <svg width="26" height="26" viewBox="0 0 26 26" aria-hidden="true" focusable="false">
            <path
              d="M13 24c0-7-5-8-5-14a5 5 0 0 1 10 0c0 6-5 7-5 14Z"
              fill="none"
              stroke="currentColor"
              strokeWidth="1.7"
            />
            <path d="M13 24V13" stroke="currentColor" strokeWidth="1.7" />
          </svg>
          <span>Greenhouse</span>
        </NavLink>
        <nav className="nav__links" aria-label="Primary">
          <NavLink to="/" end className={({ isActive }) => (isActive ? 'is-active' : undefined)}>
            Home
          </NavLink>
          <NavLink to="/dashboard" className={({ isActive }) => (isActive ? 'is-active' : undefined)}>
            My plants
          </NavLink>
        </nav>
      </div>
    </header>
  );
}
