export default function Footer() {
  return (
    <footer
      style={{
        borderTop: '1px solid var(--color-line)',
        marginTop: '4rem',
        padding: '2rem 0',
      }}
    >
      <div className="container" style={{ display: 'flex', justifyContent: 'space-between', flexWrap: 'wrap', gap: '0.75rem' }}>
        <p style={{ margin: 0, fontSize: '0.9rem', color: 'var(--color-ink-soft)' }}>
          Greenhouse — a coursework project. Built to practice front-end fundamentals, not for production use.
        </p>
        <p style={{ margin: 0, fontSize: '0.9rem', color: 'var(--color-ink-soft)' }}>Made with React + Vite</p>
      </div>
    </footer>
  );
}
